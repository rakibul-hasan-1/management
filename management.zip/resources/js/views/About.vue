<template>
  <div class="container mx-auto">
    <h1 class="text-primary">About</h1>
  </div>
</template>



