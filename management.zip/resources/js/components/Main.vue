<template>
    <div class="container my-2">
        <div class="row justify-content-center">
            <div class="col-3">
                Menu
            </div>
            <div class="col-9">
                Content
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Main mounted.')
        }
    }
</script>
