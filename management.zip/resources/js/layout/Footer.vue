<script>
export default {}
</script>

<template>
    <footer class="mt-10">
        <div class="container-fluid mx-auto">
            <BaseCard class="">
                <div class="flex justify-between items-center">
                    <div>
                        <p>All rights reserved © UI Lib 2021</p>
                    </div>
                </div>
            </BaseCard>
        </div>
    </footer>
</template>
