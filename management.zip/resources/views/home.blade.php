@extends('layouts.app')

@section('content')
{{-- <example-component></example-component> --}}
<app-component></app-component>
@endsection
